import './Card.css'
const Card = (props) => {
    return <div id="card">
     <button id="closeBtn">x</button>
      <img id="card_image" src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/33/Haeckel_Bryozoa.jpg/1280px-Haeckel_Bryozoa.jpg" alt="" />
      <h2>Title: {props.title}</h2>
     <button id="dislikeBtn">-</button>
     <img id="brokenHeart" src="https://cdn-icons-png.flaticon.com/128/725/725030.png" alt="" />
     <img id="heart" src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f1/Heart_coraz%C3%B3n.svg/1920px-Heart_coraz%C3%B3n.svg.png" alt="" />
     <span id="neutral_value">0</span>
     <button id="likeBtn">+</button>
    </div>
  }


  
  export default Card


