import { useState } from 'react'
import './App.css'
import Header from './Header.jsx'
import Footer from './Footer.jsx'
import Card from './Card.jsx'

function App() {

  return (
    <>
      <Header logo="Mohsin Rony"/>
      <main>
        <h1>Animals</h1>
        <Card/>
        <Card/>
        <Card/>
        <Card/>
        <Card/>
        <Card/>
        <Card/>
        <Card/>
      </main>
      
         <Footer footer="Copyright 2023"/>
   </>
  )
}

export default App;
