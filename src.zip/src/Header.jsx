const Header = (props) => {
    return <header>
     <h1>Mohsin's Zoo</h1>
 </header> 
 }
 export default Header;


