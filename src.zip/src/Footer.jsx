const Footer = (props) => {
    return <footer>{props.footer}</footer>
}
export default Footer;


